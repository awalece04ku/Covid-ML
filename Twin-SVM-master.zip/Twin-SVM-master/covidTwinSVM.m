
% TO KNOW MORE
% https://www.mathworks.com/help/deeplearning/ref/plotconfusion.html;jsessionid=fc3d3d2ff237fb2c32c8a7e76960 

clc
clear all


workingFolder='C:\Users\AbdulAwal\Desktop\Twin-SVM-master\';
% npylist = dir([workingFolder,'/' '*.npy']);
cd(workingFolder)
npylist_with_ADASYN= {'predict_twinSVM.npy';'predict_twinSVM_RBF.npy'};
    %  npylist={'LDA_opt_clf_predict_org.npy';'QLDA_opt_clf_predict_org.npy';'KNN_opt_predict_org.npy';'NB_Opt_clf_predict_org.npy';'DT_opt_clf_predict_org.npy';'RF_opt_clf_predict_org.npy';'XGB_opt_clf_predict_org.npy';'gbcoptclf_predict_org.npy';'SVC_opt_predict_org.npy'};


No_of_npylist=length(npylist_with_ADASYN);
All_RESULT=[];
for npy=1:No_of_npylist
    
    fname = npylist_with_ADASYN{npy};
    Predicted_Label = readNPY(fname);
    
   
     test_label = readNPY('y_test.npy');
%       test_label = readNPY('test_label_org.npy');
    [c_matrixp,Result]= confusion1.getMatrix(test_label,Predicted_Label,0);
    allRESULT_tmp=[Result.Accuracy Result.Error Result.F1_score Result.FalsePositiveRate Result.Kappa Result.MatthewsCorrelationCoefficient Result.Precision Result.Sensitivity Result.Specificity].*100;
     All_RESULT=[All_RESULT; allRESULT_tmp ];
    
     
     test_label(test_label==0)=2;
Predicted_Label(Predicted_Label==0)=2;

% figure
hh = figure(npy)
confusion_matrix_plotting(test_label,Predicted_Label);
h = gca;
h.XTickLabel = {'Covid','Non-Covid','Overall'};
h.XTickLabelRotation = 0;
h.YTickLabel ={'Covid','Non-covid','Overall'};
h.YTickLabelRotation = 90;
[C,k] = strsplit(fname,'.npy');
title(['Confusion Matrix Using ',C{1}])
savefig(hh,[C{1},'_Confusion_matrix.fig'])

% exportgraphics(hh,[C{1},'_Confusion_matrix.png'],'Resolution',1200)

clear h hh C test_label Predicted_Label
     
     
    
end


T_with_ADASYN = array2table(All_RESULT,'RowNames',{'predict_twinSVM.npy';'predict_twinSVM_RBF.npy'},...,
    'VariableNames',{'Accuracy','Error','F1_score','FalsePositiveRate','Kappa','MatthewsCorrelationCoefficient','Precision','Sensitivity','Specificity'})
writetable(T_with_ADASYN,'COVIDdat_TwinSVM.csv','WriteRowNames', true )
save All_RESULT_TwinSVM All_RESULT T_with_ADASYN



% 
% T_without_ADASYN = array2table(All_RESULT,'RowNames',{'LDA_opt_clf_predict_org.npy';'QLDA_opt_clf_predict_org.npy';'KNN_opt_predict_org.npy';'NB_Opt_clf_predict_org.npy';'DT_opt_clf_predict_org.npy';'RF_opt_clf_predict_org.npy';'XGB_opt_clf_predict_org.npy';'gbcoptclf_predict_org.npy';'SVC_opt_predict_org.npy'},...,
%     'VariableNames',{'Accuracy','Error','F1_score','FalsePositiveRate','Kappa','MatthewsCorrelationCoefficient','Precision','Sensitivity','Specificity'})
% 
% writetable(T_without_ADASYN,'NHANES_test_data_without_ADASYN_Results_Clinical.csv','WriteRowNames', true )
% save All_RESULT All_RESULT T_without_ADASYN




% [c_matrixp,Result]= confusion1.getMatrix(test_label,Predicted_Label,1);
% allRESULT_tmp=[Result.Accuracy Result.Error Result.F1_score Result.FalsePositiveRate Result.Kappa Result.MatthewsCorrelationCoefficient Result.Precision Result.Sensitivity Result.Specificity].*100

