# Covid-ML
This repository contains code for the paper titled "Development of a Smartphone-based Expert System for Covid-19 Risk Prediction at Early Stage", which has been submitted to Arabian Journal for Science and Engineering. The overall graphical block diagram of our proposed approached is illustrated in Figure below.
![faa0c328-2bec-4203-89db-ec089c27a1c8](https://user-images.githubusercontent.com/44156683/155388449-7b4afdac-99c5-4f17-83c7-d33475e8a7fb.png)
